enum SeatStage { overview, selecting, selected }
