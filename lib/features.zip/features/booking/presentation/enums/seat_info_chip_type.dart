enum SeatInfoChipType { date, time }
