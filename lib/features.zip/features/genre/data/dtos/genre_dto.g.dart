// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'genre_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_GenreDto _$GenreDtoFromJson(Map<String, dynamic> json) =>
    _GenreDto(id: (json['id'] as num).toInt(), name: json['name'] as String);

Map<String, dynamic> _$GenreDtoToJson(_GenreDto instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
};
